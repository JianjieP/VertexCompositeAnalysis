from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = False
config.General.requestName = 'HIForward6_HIRun2023A-14Feb2025-v1_FourPi_0520'
config.General.workArea = 'crab_projects_0520'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'PbPbSkimAndTree2023_FourPi_cfg.py'
config.JobType.maxJobRuntimeMin = 1100
config.JobType.allowUndistributedCMSSW = True
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/jianjie/fourpi/HIForward6/'
config.Data.inputDBS = 'global'
config.Data.allowNonValidInputDataset = True
config.Data.publication = False
config.Data.splitting = 'LumiBased'
config.Data.inputDataset = '/HIForward6/HIRun2023A-14Feb2025-v1/MINIAOD'
config.Data.lumiMask = 'Cert_Collisions2023HI_374288_375823_Golden.json'
config.Data.outputDatasetTag = 'HIForward6_HIRun2023A-14Feb2025-v1_FourPi_0520'
config.Data.unitsPerJob = 20
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
