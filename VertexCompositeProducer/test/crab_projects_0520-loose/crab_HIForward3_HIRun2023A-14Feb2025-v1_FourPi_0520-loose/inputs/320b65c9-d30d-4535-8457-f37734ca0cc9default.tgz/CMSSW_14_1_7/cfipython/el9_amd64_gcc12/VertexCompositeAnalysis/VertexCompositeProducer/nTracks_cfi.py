import FWCore.ParameterSet.Config as cms

from .NTrackVertexMapper import NTrackVertexMapper

nTracks = NTrackVertexMapper()
