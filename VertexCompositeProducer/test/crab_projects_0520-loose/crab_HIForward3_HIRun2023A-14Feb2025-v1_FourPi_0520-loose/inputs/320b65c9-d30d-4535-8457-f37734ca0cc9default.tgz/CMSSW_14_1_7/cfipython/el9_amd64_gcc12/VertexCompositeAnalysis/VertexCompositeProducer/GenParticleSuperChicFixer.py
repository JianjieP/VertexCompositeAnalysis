import FWCore.ParameterSet.Config as cms

def GenParticleSuperChicFixer(**kwargs):
  mod = cms.EDProducer('GenParticleSuperChicFixer',
    genPars = cms.InputTag('genParticles', '', 'SIM'),
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
