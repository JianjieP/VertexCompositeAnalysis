from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.workArea = 'crab_projects_0520-loose'
config.General.requestName = 'HIForward2_HIRun2023A-14Feb2025-v1_FourPi_0520-loose'
config.General.transferLogs = False
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 1100
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = 'PbPbSkimAndTree2023_FourPi_cfg.py'
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.outputDatasetTag = 'HIForward2_HIRun2023A-14Feb2025-v1_FourPi_0520-loose'
config.Data.unitsPerJob = 20
config.Data.lumiMask = 'Cert_Collisions2023HI_374288_375823_Golden.json'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/HIForward2/HIRun2023A-14Feb2025-v1/MINIAOD'
config.Data.outLFNDirBase = '/store/user/jianjie/fourpi/HIForward2/'
config.Data.publication = False
config.Data.splitting = 'LumiBased'
config.Data.allowNonValidInputDataset = True
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
