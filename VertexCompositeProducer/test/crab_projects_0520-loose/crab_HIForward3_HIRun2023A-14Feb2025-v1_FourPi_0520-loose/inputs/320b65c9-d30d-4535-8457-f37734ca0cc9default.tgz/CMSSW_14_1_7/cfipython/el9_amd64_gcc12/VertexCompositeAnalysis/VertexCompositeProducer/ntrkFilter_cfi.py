import FWCore.ParameterSet.Config as cms

from .MultFilter import MultFilter

ntrkFilter = MultFilter()
