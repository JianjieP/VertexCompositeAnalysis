import FWCore.ParameterSet.Config as cms

from .DeDxMuonProducer import DeDxMuonProducer

dedxMuon = DeDxMuonProducer()
