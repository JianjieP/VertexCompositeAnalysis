import FWCore.ParameterSet.Config as cms

def GenParticleFixer(**kwargs):
  mod = cms.EDProducer('GenParticleFixer',
    genPars = cms.InputTag('genParticles', '', 'SIM'),
    momPdgId = cms.int32(0),
    dauPdgId = cms.int32(13),
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
