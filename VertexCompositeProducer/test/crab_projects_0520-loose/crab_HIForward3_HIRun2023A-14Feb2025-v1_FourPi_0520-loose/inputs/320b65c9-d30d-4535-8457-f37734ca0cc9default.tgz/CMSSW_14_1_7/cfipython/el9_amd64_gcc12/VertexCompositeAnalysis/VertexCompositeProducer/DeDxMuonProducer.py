import FWCore.ParameterSet.Config as cms

def DeDxMuonProducer(**kwargs):
  mod = cms.EDProducer('DeDxMuonProducer',
    dedx = cms.InputTag('dedxHarmonic2'),
    muons = cms.InputTag('patMuonsWithoutTrigger'),
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
