import FWCore.ParameterSet.Config as cms

def NTrackVertexMapper(**kwargs):
  mod = cms.EDProducer('NTrackVertexMapper',
    primaryVertices = cms.InputTag('offlinePrimaryVertices'),
    tracks = cms.InputTag('generalTracks'),
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
