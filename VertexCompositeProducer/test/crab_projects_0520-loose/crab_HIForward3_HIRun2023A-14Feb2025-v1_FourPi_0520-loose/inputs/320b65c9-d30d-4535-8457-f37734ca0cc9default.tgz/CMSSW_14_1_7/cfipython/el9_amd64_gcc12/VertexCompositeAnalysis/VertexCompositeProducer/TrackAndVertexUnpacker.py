import FWCore.ParameterSet.Config as cms

def TrackAndVertexUnpacker(**kwargs):
  mod = cms.EDProducer('TrackAndVertexUnpacker',
    packedCandidates = cms.VInputTag(
      'packedPFCandidates',
      'lostTracks',
      'lostTracks:eleTracks'
    ),
    packedCandidateNormChi2Map = cms.VInputTag(
      'packedPFCandidateTrackChi2',
      'lostTrackChi2',
      ''
    ),
    primaryVertices = cms.InputTag('offlineSlimmedPrimaryVertices'),
    secondaryVertices = cms.InputTag('slimmedSecondaryVertices'),
    dedxEstimators = cms.VInputTag(
      'dedxEstimator:dedxAllLikelihood',
      'dedxEstimator:dedxPixelLikelihood',
      'dedxEstimator:dedxStripLikelihood',
      'dedxEstimator:dedxPixelHarmonic2'
    ),
    recoverTracks = cms.bool(False),
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
