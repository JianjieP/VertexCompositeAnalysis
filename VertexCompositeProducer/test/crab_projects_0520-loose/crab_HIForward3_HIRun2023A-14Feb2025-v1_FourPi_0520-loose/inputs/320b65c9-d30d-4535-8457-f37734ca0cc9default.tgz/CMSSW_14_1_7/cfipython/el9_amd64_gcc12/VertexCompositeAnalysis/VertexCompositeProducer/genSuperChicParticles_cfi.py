import FWCore.ParameterSet.Config as cms

from .GenParticleSuperChicFixer import GenParticleSuperChicFixer

genSuperChicParticles = GenParticleSuperChicFixer()
