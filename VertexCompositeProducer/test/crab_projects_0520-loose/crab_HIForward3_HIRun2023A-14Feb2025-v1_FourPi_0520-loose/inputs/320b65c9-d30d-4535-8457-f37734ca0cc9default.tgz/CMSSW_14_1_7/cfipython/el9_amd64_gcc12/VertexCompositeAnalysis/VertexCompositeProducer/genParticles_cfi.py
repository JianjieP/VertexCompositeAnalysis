import FWCore.ParameterSet.Config as cms

from .GenParticleFixer import GenParticleFixer

genParticles = GenParticleFixer()
